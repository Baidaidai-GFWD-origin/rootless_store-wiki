echo "This is a Demo Shell Script for Rootless Stroe";

sleep 0.5;

echo "Hello, world";